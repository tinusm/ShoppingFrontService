/*jshint node:true*/
(function () {
  'use strict';

  var chai = require('chai');
  global.chai = chai;
  global.should = chai.should();
  global.expect = chai.expect;
  global.assert = chai.assert;

})();
